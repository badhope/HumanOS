import{at as t,c}from"./ui-B2_zUYrv.js";function e(...r){return t(c(r))}export{e as c};
